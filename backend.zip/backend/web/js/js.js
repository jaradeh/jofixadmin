$('.glyphicon-eye-open').addClass('fa fa-eye');
$('.glyphicon-eye-open').removeClass('glyphicon-eye-open');

$('.glyphicon-pencil').addClass('fa fa-edit');
$('.glyphicon-pencil').removeClass('glyphicon-pencil');

$('.glyphicon-trash').addClass('fa fa-trash');
$('.glyphicon-trash').removeClass('glyphicon-trash');
