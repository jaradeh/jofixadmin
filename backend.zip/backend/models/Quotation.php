<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "quotation".
 *
 * @property string $alias
 * @property integer $id
 * @property string $title
 * @property integer $price
 * @property integer $date_created
 * @property integer $date_edited
 */
class Quotation extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'quotation';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['alias', 'title', 'price', 'date_created', 'date_edited'], 'required'],
            [['price', 'date_created', 'date_edited'], 'integer'],
            [['alias', 'title'], 'string', 'max' => 255],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'alias' => 'Alias',
            'id' => 'ID',
            'title' => 'Title',
            'price' => 'Price',
            'date_created' => 'Date Created',
            'date_edited' => 'Date Edited',
        ];
    }
}
